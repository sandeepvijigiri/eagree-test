package com.eagree;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.eagree.auth.conf.OrganizationService;
import com.eagree.auth.conf.UserDetailsSecurityService;
import com.eagree.auth.conf.UserService;
import com.eagree.data.domain.mysql.BaseAuditDomain;
import com.eagree.data.domain.mysql.Organization;
import com.eagree.data.domain.mysql.User;
import com.eagree.data.repository.mysql.FolderRepository;
import com.eagree.data.repository.mysql.OrganizationCompanyContactRepository;
import com.eagree.data.repository.mysql.OrganizationCompanyRepository;
import com.eagree.data.repository.mysql.OrganizationRepository;
import com.eagree.data.repository.mysql.PrivilegeRepository;
import com.eagree.data.repository.mysql.RoleRepository;
import com.eagree.data.repository.mysql.UserRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class ApplicationTests {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private FolderRepository folderRepository;
	
	@Autowired
	private PrivilegeRepository privilegeRepository;
	
	@Autowired
	private OrganizationCompanyRepository organizationCompanyRepository;
	
	@Autowired
	private OrganizationCompanyContactRepository organizationCompanyContactRepository;
	
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDetailsSecurityService userDetailsSecurityService;
	
	@Autowired
	private OrganizationService organizationService ;
	
	
	
	@Test
	public void contextLoads() {
	}
	
	@Test
	public void jpaRepositoriesNotNull() {
		
		assertNotNull(userRepository);
		assertNotNull(roleRepository);
	    assertNotNull(organizationRepository);
		assertNotNull(folderRepository);
		assertNotNull(privilegeRepository);
		assertNotNull(organizationCompanyRepository);
		assertNotNull(organizationCompanyContactRepository);
		
	}
	
	@Test
	public void userDetailsServiceNotNull() {
		assertNotNull(userService);
		assertNotNull(userDetailsSecurityService);
	}
	
	@Test
	public void adminUserTest(){
		User user = new User();
		user.setPassword("abc");
		user.setEmailAddress("sandeep.vijigiri@gabacorp.net");
		user.setRegistrationType("abcd");
		user.setCreatedBy(user);
		user.setLastUpdated(new Date());
		user.setCreatedDate(new Date());
		userService.createUser(user);
	}
	
	@Test
	public void userOrganizationTest(){
		User adminUser=userRepository.findByEmailAddress("sandeep.vijigiri@gabacorp.net");
		Organization organization=organizationRepository.findByUsers(adminUser);
	}
	
}
