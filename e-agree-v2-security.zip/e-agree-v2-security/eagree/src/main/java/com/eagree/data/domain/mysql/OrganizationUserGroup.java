package com.eagree.data.domain.mysql;

public class OrganizationUserGroup {

}
