package com.eagree.data.repository.mysql;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagree.data.domain.mysql.OrganizationCompany;

public interface OrganizationCompanyRepository extends JpaRepository <OrganizationCompany, Long> {
	
	OrganizationCompany findByName(String name);
}
