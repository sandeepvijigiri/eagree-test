package com.eagree.auth.conf;

import com.eagree.data.domain.mysql.Organization;


public interface OrganizationService {

	public Organization createOrganization(Organization organization);
		
	
}
