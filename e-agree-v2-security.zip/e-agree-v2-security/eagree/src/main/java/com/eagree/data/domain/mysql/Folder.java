package com.eagree.data.domain.mysql;

import javax.persistence.Entity;

@Entity
public class Folder extends BaseAuditDomain {

	
	
}
