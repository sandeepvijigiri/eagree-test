package com.eagree.data.domain.mysql;

public enum CompanyType {

}
