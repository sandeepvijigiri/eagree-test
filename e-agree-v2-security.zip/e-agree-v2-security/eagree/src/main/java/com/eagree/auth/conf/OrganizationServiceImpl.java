package com.eagree.auth.conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eagree.data.domain.mysql.Organization;
import com.eagree.data.repository.mysql.OrganizationRepository;

@Service
public class OrganizationServiceImpl implements OrganizationService  {

	@Autowired
	OrganizationRepository orgDao;

	@Override
	public Organization createOrganization(Organization organization) {
		// TODO Auto-generated method stub
		return orgDao.save(organization);
	}
	
	
}

