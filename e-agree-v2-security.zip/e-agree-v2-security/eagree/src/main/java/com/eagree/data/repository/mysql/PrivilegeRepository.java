package com.eagree.data.repository.mysql;
import org.springframework.data.jpa.repository.JpaRepository;

import com.eagree.data.domain.mysql.Privilege;

public interface PrivilegeRepository extends JpaRepository<Privilege, Long>{
   
	Privilege findByPrivilegeName(String privilegeName);
}
