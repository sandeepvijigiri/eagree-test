package com.eagree.data.repository.mysql;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagree.data.domain.mysql.OrganizationCompanyContact;


public interface OrganizationCompanyContactRepository extends JpaRepository<OrganizationCompanyContact,Long>{

	OrganizationCompanyContact findBycompanyName(String contactEmail);
}
