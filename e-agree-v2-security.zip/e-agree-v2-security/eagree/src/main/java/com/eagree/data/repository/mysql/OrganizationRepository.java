package com.eagree.data.repository.mysql;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eagree.data.domain.mysql.Organization;
import com.eagree.data.domain.mysql.User;

public interface OrganizationRepository extends JpaRepository<Organization, Long> {
	Organization findByorgName(String orgName);
	Organization findByUsers(User user);
}
