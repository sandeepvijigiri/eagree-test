package com.eagree.auth.conf;

import com.eagree.data.domain.mysql.*;

public interface UserService {

    public User getUserByEmail(String email);

    public User getUserById(long id);

    public Iterable<User> getAllUsers();

    public User createUser(User user);
}
