package com.eagree.auth.conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import com.eagree.data.domain.mysql.User;
import com.eagree.data.repository.mysql.*;;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userDao;
	
	@Override
	public User getUserByEmail(String email) {
		return userDao.findByEmailAddress(email);
	}

	@Override
	public User getUserById(long id) {
		return userDao.findOne(id);
	}

	@Override
	public Iterable<User> getAllUsers() {
		return userDao.findAll();
	}

	@Override
	public User createUser(User user) {
		user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
	   return	userDao.save(user);
	
	}
}
